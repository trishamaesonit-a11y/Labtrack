# LabTrack 1.2 – fixes over 1.1

| File | What was wrong / what changed |
|---|---|
| `includes/connection.php` | **Main bug:** line 1 was a stray markdown fence (```php) copied in by mistake. PHP printed it before `<?php`, which breaks sessions, login redirects ("headers already sent") and shows junk text. Removed it. Also removed the leftover `const_dummy_placeholder:` line, made the localhost check work with any port, added a clear message when the hosted `YOUR_...` placeholders are not filled in, added the optional `LABTRACK_DEBUG` switch, and stopped oversized uploads from showing a misleading "Invalid or expired form token" error. |
| `includes/layout.php` | The unread-message badge counted **group-chat messages** as admin/user messages (group messages have no recipient), so the badge could never clear. Added `m.group_id IS NULL` to both queries. |
| `user/dashboard.php` | **Privacy bug:** "Latest messages" showed group-chat messages sent by an admin to every student/staff user, even non-members. Added `m.group_id IS NULL`. |
| `README.md` | Documents where the database settings are and how to debug a connection error. |
| `uploads/profile_photos/index.html` | New empty file so the folder cannot be browsed as a file list. |

Everything else is unchanged from 1.1. No database changes are needed.
