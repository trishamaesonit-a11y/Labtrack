-- ============================================================
--  LABTRACK  -  MySQL / MariaDB schema + sample data
--  Import via phpMyAdmin (Import tab) or:  mysql -u root < database.sql
--  Every table has a created_at timestamp (set automatically).
--  Demo accounts (password for all: "password")
--     admin / jdelacruz (staff) / msantos (student) / rreyes (student) / akim (staff)
-- ============================================================
CREATE DATABASE IF NOT EXISTS labtrack CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE labtrack;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS user_conversations, group_members, group_chats, messages, fines, maintenance_logs, borrow_records, equipment, categories, users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------- USERS ----------
CREATE TABLE users (
  user_id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username       VARCHAR(60)  NOT NULL UNIQUE,
  password_hash  VARCHAR(255) NOT NULL,
  full_name      VARCHAR(120) NOT NULL,
  email          VARCHAR(150) NOT NULL UNIQUE,
  role           ENUM('admin','student','staff') NOT NULL DEFAULT 'student',
  department     VARCHAR(100) NOT NULL DEFAULT '',
  phone          VARCHAR(40)  NOT NULL DEFAULT '',
  bio            TEXT NULL,
  profile_photo  VARCHAR(255) NULL,
  status         ENUM('active','disabled') NOT NULL DEFAULT 'active',
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

-- ---------- CATEGORY ----------
CREATE TABLE categories (
  category_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  category_name  VARCHAR(100) NOT NULL UNIQUE,
  description    VARCHAR(255) NOT NULL DEFAULT '',
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------- EQUIPMENT ----------
CREATE TABLE equipment (
  equipment_id     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  equipment_name   VARCHAR(150) NOT NULL,
  category_id      INT UNSIGNED NULL,
  description      TEXT NULL,
  image_url        VARCHAR(255) NULL,
  serial_number    VARCHAR(80)  NOT NULL DEFAULT '',
  status           ENUM('Available','Borrowed','Maintenance','Retired') NOT NULL DEFAULT 'Available',
  condition_status VARCHAR(40)  NOT NULL DEFAULT 'Good',
  quantity         INT UNSIGNED NOT NULL DEFAULT 1,
  location         VARCHAR(100) NOT NULL DEFAULT '',
  department       VARCHAR(100) NOT NULL DEFAULT '',
  purchase_date    DATE NULL,
  last_maintenance DATE NULL,
  qr_code          VARCHAR(40)  NOT NULL DEFAULT '',
  usage_count      INT UNSIGNED NOT NULL DEFAULT 0,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_eq_status (status),
  CONSTRAINT fk_eq_cat FOREIGN KEY (category_id) REFERENCES categories(category_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- BORROW RECORD ----------
CREATE TABLE borrow_records (
  borrow_id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  equipment_id         INT UNSIGNED NOT NULL,
  user_id              INT UNSIGNED NOT NULL,
  status               ENUM('Requested','Approved','Borrowed','Returned','Rejected') NOT NULL DEFAULT 'Requested',
  borrow_date          DATETIME NULL,
  expected_return_date DATE NOT NULL,
  actual_return_date   DATETIME NULL,
  notes                VARCHAR(255) NOT NULL DEFAULT '',
  condition_at_borrow  VARCHAR(40) NULL,
  condition_at_return  VARCHAR(40) NULL,
  approved_by          INT UNSIGNED NULL,
  created_at           TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_br_status (status),
  CONSTRAINT fk_br_eq   FOREIGN KEY (equipment_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE,
  CONSTRAINT fk_br_user FOREIGN KEY (user_id)      REFERENCES users(user_id)          ON DELETE CASCADE,
  CONSTRAINT fk_br_appr FOREIGN KEY (approved_by)  REFERENCES users(user_id)          ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------- FINES / PENALTY RECORD ----------
CREATE TABLE fines (
  fine_id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  borrow_id         INT UNSIGNED NULL,
  user_id           INT UNSIGNED NOT NULL,
  days_overdue      INT UNSIGNED NOT NULL DEFAULT 0,
  amount            DECIMAL(10,2) NOT NULL DEFAULT 0,
  reason            VARCHAR(255) NOT NULL DEFAULT 'Late return',
  status            ENUM('Unpaid','Pending','Paid','Waived') NOT NULL DEFAULT 'Unpaid',
  payment_method    ENUM('None','Cash','GCash','Maya','Bank Transfer','Card') NOT NULL DEFAULT 'None',
  payment_reference VARCHAR(100) NULL,
  approved_by       INT UNSIGNED NULL,
  paid_at           DATETIME NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_fines_status (status),
  CONSTRAINT fk_fine_borrow FOREIGN KEY (borrow_id) REFERENCES borrow_records(borrow_id) ON DELETE SET NULL,
  CONSTRAINT fk_fine_user   FOREIGN KEY (user_id)   REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- MAINTENANCE LOG ----------
CREATE TABLE maintenance_logs (
  log_id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  equipment_id          INT UNSIGNED NOT NULL,
  maintenance_date      DATE NOT NULL,
  description           VARCHAR(255) NOT NULL DEFAULT '',
  cost                  DECIMAL(10,2) NOT NULL DEFAULT 0,
  technician            VARCHAR(100) NOT NULL DEFAULT '',
  next_maintenance_date DATE NULL,
  trigger_type          ENUM('time','usage') NOT NULL DEFAULT 'time',
  created_at            TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ml_eq FOREIGN KEY (equipment_id) REFERENCES equipment(equipment_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- GROUP CHATS ----------
CREATE TABLE group_chats (
  group_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_name VARCHAR(120) NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_gc_creator FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE group_members (
  group_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (group_id, user_id),
  CONSTRAINT fk_gm_group FOREIGN KEY (group_id) REFERENCES group_chats(group_id) ON DELETE CASCADE,
  CONSTRAINT fk_gm_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- MESSAGE RECORD ----------
-- recipient_id set  => private direct message between sender and recipient
-- recipient_id NULL => legacy message to the admin team or admin broadcast
CREATE TABLE messages (
  message_id    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sender_id     INT UNSIGNED NOT NULL,
  recipient_id  INT UNSIGNED NULL,
  group_id      INT UNSIGNED NULL,
  subject       VARCHAR(150) NOT NULL DEFAULT '',
  body          TEXT NOT NULL,
  is_read       TINYINT(1) NOT NULL DEFAULT 0,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_msg_created (created_at),
  CONSTRAINT fk_msg_sender FOREIGN KEY (sender_id)    REFERENCES users(user_id) ON DELETE CASCADE,
  CONSTRAINT fk_msg_recip  FOREIGN KEY (recipient_id) REFERENCES users(user_id) ON DELETE SET NULL,
  CONSTRAINT fk_msg_group FOREIGN KEY (group_id) REFERENCES group_chats(group_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- PER-USER CONVERSATION INBOX STATE ----------
-- Archive/delete only affects the current user's inbox; message records are retained.
CREATE TABLE user_conversations (
  user_id          INT UNSIGNED NOT NULL,
  conversation_type ENUM('direct','group') NOT NULL,
  conversation_id  INT UNSIGNED NOT NULL,
  is_archived      TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted       TINYINT(1) NOT NULL DEFAULT 0,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, conversation_type, conversation_id),
  CONSTRAINT fk_uc_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
--  SAMPLE DATA
-- ============================================================
INSERT INTO users (user_id, username, password_hash, full_name, email, role, department, created_at) VALUES
 (1,'admin',     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Admin User',     'admin@labtrack.edu',     'admin',  'IT Office','2026-01-05 08:00:00'),
 (2,'jdelacruz', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Juan Dela Cruz', 'jdelacruz@school.edu',  'staff',  'CCS',      '2026-01-06 09:00:00'),
 (3,'msantos',   '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Maria Santos',   'msantos@school.edu',    'student','CAS',      '2026-01-10 10:00:00'),
 (4,'rreyes',    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Rico Reyes',     'rreyes@school.edu',     'student','COE',      '2026-01-12 10:30:00'),
 (5,'akim',      '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','Ana Kim',        'akim@school.edu',       'staff',  'COE',      '2026-02-01 11:00:00');

INSERT INTO categories (category_id, category_name, description, created_at) VALUES
 (1,'Laptops','Portable computers for student/staff use','2026-01-05 08:10:00'),
 (2,'Microscopes','Optical & digital microscopes for lab use','2026-01-05 08:11:00'),
 (3,'Projectors','Classroom and conference projectors','2026-01-05 08:12:00'),
 (4,'Power Tools','Engineering workshop equipment','2026-01-05 08:13:00'),
 (5,'Electronics','Meters, microcontrollers and kits','2026-01-05 08:14:00');

INSERT INTO equipment (equipment_id, equipment_name, category_id, description, serial_number, status, condition_status, quantity, location, department, purchase_date, last_maintenance, qr_code, usage_count, created_at) VALUES
 (1,'Dell Latitude 5440',1,'i5, 16GB RAM','DL-5440-001','Available','Good',1,'IT Lab 1','CCS','2024-01-10','2026-06-01','EQ-0001',12,'2026-01-05 09:00:00'),
 (2,'Olympus CX23 Microscope',2,'Binocular, LED illumination','OLY-CX23-014','Borrowed','Good',1,'Bio Lab','CAS','2023-08-15','2026-02-20','EQ-0002',34,'2026-01-05 09:05:00'),
 (3,'Epson EB-X51 Projector',3,'3600 lumens','EPS-X51-9','Maintenance','Fair',1,'Room 204','CCS','2022-05-01','2025-08-10','EQ-0003',88,'2026-01-05 09:10:00'),
 (4,'Bosch Cordless Drill',4,'18V, 2 batteries','BSH-DR-22','Available','Good',3,'Engg Workshop','COE','2024-03-20','2026-04-01','EQ-0004',5,'2026-01-05 09:15:00'),
 (5,'Arduino Starter Kit',5,'UNO R3 + sensors','ARD-KIT-07','Borrowed','Good',1,'Electronics Lab','COE','2025-02-11',NULL,'EQ-0005',9,'2026-01-06 09:00:00'),
 (6,'Fluke Digital Multimeter',5,'True-RMS, CAT III','FLK-117-03','Available','Good',2,'Electronics Lab','COE','2024-11-02',NULL,'EQ-0006',21,'2026-01-06 09:10:00');

INSERT INTO borrow_records (borrow_id, equipment_id, user_id, status, borrow_date, expected_return_date, actual_return_date, notes, condition_at_borrow, condition_at_return, approved_by, created_at) VALUES
 (1, 1,3,'Returned','2026-01-13 09:00:00','2026-01-20','2026-01-19 15:00:00','Thesis writing','Good','Good',1,'2026-01-12 14:00:00'),
 (2, 2,4,'Returned','2026-02-04 09:00:00','2026-02-11','2026-02-14 10:00:00','Lab report','Good','Good',1,'2026-02-03 13:00:00'),
 (3, 6,2,'Returned','2026-03-10 08:30:00','2026-03-17','2026-03-16 16:00:00','Class demo','Good','Good',1,'2026-03-09 10:00:00'),
 (4, 4,5,'Returned','2026-04-15 09:00:00','2026-04-22','2026-04-22 11:00:00','Workshop build','Good','Good',1,'2026-04-14 09:30:00'),
 (5, 1,4,'Returned','2026-05-06 09:00:00','2026-05-13','2026-05-18 09:00:00','Project coding','Good','Fair',1,'2026-05-05 15:00:00'),
 (6, 5,3,'Returned','2026-06-03 09:00:00','2026-06-10','2026-06-09 14:00:00','Robotics club','Good','Good',1,'2026-06-02 11:00:00'),
 (7, 3,2,'Returned','2026-07-08 08:00:00','2026-07-15','2026-07-15 17:00:00','Seminar','Good','Fair',1,'2026-07-07 09:00:00'),
 (8, 6,3,'Returned','2026-08-12 09:00:00','2026-08-19','2026-08-19 13:00:00','Circuits lab','Good','Good',1,'2026-08-11 10:00:00'),
 (9, 1,5,'Returned','2026-09-09 09:00:00','2026-09-16','2026-09-20 10:00:00','Training','Good','Good',1,'2026-09-08 08:30:00'),
 (10,2,3,'Borrowed','2026-09-15 09:00:00','2026-09-22',NULL,'For thesis experiment','Good',NULL,1,'2026-09-14 16:00:00'),
 (11,5,4,'Borrowed','2026-10-09 09:00:00','2026-10-16',NULL,'Capstone prototype','Good',NULL,1,'2026-10-08 12:00:00'),
 (12,6,5,'Requested',NULL,'2026-10-21',NULL,'Need for class demo',NULL,NULL,NULL,'2026-10-14 10:00:00'),
 (13,4,3,'Requested',NULL,'2026-10-22',NULL,'Furniture project',NULL,NULL,NULL,'2026-10-15 08:00:00');

INSERT INTO fines (fine_id, borrow_id, user_id, days_overdue, amount, reason, status, payment_method, payment_reference, approved_by, paid_at, created_at) VALUES
 (1,2,4,3,60.00,'Late return','Paid','GCash','GC-10023',1,'2026-02-16 10:00:00','2026-02-14 10:00:00'),
 (2,5,4,5,100.00,'Late return','Unpaid','None',NULL,NULL,NULL,'2026-05-18 09:00:00'),
 (3,9,5,4,80.00,'Late return','Pending','GCash','GC-77821',NULL,NULL,'2026-09-20 10:00:00'),
 (4,NULL,3,0,150.00,'Damaged charger cable','Unpaid','None',NULL,NULL,NULL,'2026-08-20 09:00:00');

INSERT INTO maintenance_logs (log_id, equipment_id, maintenance_date, description, cost, technician, next_maintenance_date, trigger_type, created_at) VALUES
 (1,3,'2025-08-10','Lamp replacement + filter cleaning',1500.00,'TechServ Inc.','2026-02-10','time','2025-08-10 15:00:00'),
 (2,1,'2026-06-01','Keyboard cleaning and OS update',0.00,'IT Office','2026-12-01','time','2026-06-01 10:00:00'),
 (3,2,'2026-02-20','Lens calibration',800.00,'OptiCare','2026-08-20','time','2026-02-20 11:00:00'),
 (4,4,'2026-04-01','Battery replacement',2400.00,'Bosch Service','2026-10-01','usage','2026-04-01 09:00:00');

INSERT INTO messages (message_id, sender_id, recipient_id, subject, body, is_read, created_at) VALUES
 (1,3,NULL,'Extension request','Good day! May I extend the microscope borrowing by two days?',0,'2026-10-13 09:15:00'),
 (2,1,3,'Re: Extension request','Approved until Oct 24. Please return it in good condition.',1,'2026-10-13 10:00:00'),
 (3,5,NULL,'Payment sent','I paid my fine via GCash, ref GC-77821.',0,'2026-10-14 16:40:00'),
 (4,1,NULL,'Lab closure notice','The Electronics Lab will be closed on Oct 30 for inventory.',1,'2026-10-12 08:00:00');
