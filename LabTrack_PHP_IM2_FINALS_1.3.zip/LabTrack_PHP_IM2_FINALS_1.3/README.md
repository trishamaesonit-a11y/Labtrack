# LabTrack (PHP + MySQL)

Lab equipment borrowing system — PHP port of the LABTRACK 1.0 Expo app.
Green glassmorphism UI, light/dark toggle, 3 roles: **admin**, **staff**, **student**.

## Setup (XAMPP / WAMP / Laragon)
1. Copy the `labtrack_php` folder into `htdocs` (or `www`). Rename it `labtrack` if you like.
2. For a **fresh install**, open phpMyAdmin → **Import** → choose `database.sql` → Go. (It creates the `labtrack` database.) For an existing installation, back up first and run `upgrade_group_chats.sql` instead of re-importing the fresh-install script. This migration adds group-chat support, the per-user inbox archive table, and is safe to run more than once.
3. Database settings live at the top of `includes/connection.php`. On your own computer (XAMPP) it uses `localhost` / `root` / no password automatically. On a hosted site, replace the four `YOUR_...` values in the hosted block with the details from your hosting panel (InfinityFree: MySQL Databases). Never post those values in public.
   - Can't connect? Temporarily set `LABTRACK_DEBUG` to `true` in `connection.php` to see the real MySQL error, then set it back to `false`.
   - On shared hosting, remove the `CREATE DATABASE` and `USE labtrack;` lines from `database.sql` before importing into the database the host created for you.
4. Open `http://localhost/labtrack/` (PHP 7.4+ / 8.x, MySQL 5.7+ or MariaDB 10.3+).

### Firebase Google sign-in (optional)
Google sign-in uses Firebase Authentication and is limited to existing, active LabTrack accounts whose verified Google email matches their LabTrack email. It does not create accounts.
1. In the Firebase console, create a project, add a **Web app**, then enable **Authentication → Sign-in method → Google**.
2. In **Authentication → Settings → Authorized domains**, ensure `localhost` is listed for local development.
3. This project is preconfigured with the Firebase web app settings for project `project1-303d9`. You do not need to add credentials to Apache. If you replace the Firebase project, update the configuration defaults in `login.php` and the project ID fallback in `firebase_login.php` (or override them with `LABTRACK_FIREBASE_*` Apache environment variables).
4. Ensure PHP's `curl` and `openssl` extensions are enabled and the computer/server can reach Firebase and Google certificate endpoints.
5. Register only accounts that already exist in LabTrack; Google sign-in does not create a LabTrack account.

Firebase web-app configuration (including the API key and app ID) is public client configuration. Do not place Firebase Admin service-account credentials in the browser or repository; this sign-in verifies ID tokens with Google's public signing certificates and needs no Admin SDK key.

## Demo accounts — password for all: `password`
| Username   | Role    | Lands on            |
|------------|---------|---------------------|
| admin      | admin   | /admin/dashboard.php |
| jdelacruz  | staff   | /user/dashboard.php  |
| msantos    | student | /user/dashboard.php  |

Change these passwords (Settings page) or delete the demo users before real use.
Need a new hash? `php tools/make_hash.php yourpassword`

Users and admins can upload or replace their profile picture from Profile/Settings (JPG, PNG, or WebP, up to 3 MB), or provide an HTTP(S) image URL. Uploaded images are stored locally; URL-based images remain hosted by their original provider. Photo paths or URLs are recorded in the account's `profile_photo` field.

## Tables (each has `created_at`)
users · categories · equipment · borrow_records · fines · maintenance_logs · messages · group_chats · group_members

## Workflow
Student/staff requests equipment → admin **Approve** → **Release** (equipment becomes Borrowed)
→ **Return** (late returns auto-create a fine at ₱20/day — change `FINE_PER_DAY` in `connection.php`)
→ user submits payment (GCash/Maya/etc.) → admin approves it under Fines & Penalties.

Students, staff, and admins can send private messages to one another and create group chats with selected active members. The Messages inbox shows sent and received conversations; users can archive or remove conversations from their own inbox without deleting messages for other participants. The admin dashboard includes user registration analytics (total, active, this month, and role counts). Admin lists provide View details pages for equipment, borrow records, categories, maintenance logs, and fines.

## Folders
- `admin/` admin UI (sidebar dashboard layout)  ·  `user/` student + staff UI (shared top-nav layout)
- `includes/` connection (DB, helpers, CSRF, auth) and layout  ·  `assets/` CSS + JS (charts are plain SVG, no libraries)
