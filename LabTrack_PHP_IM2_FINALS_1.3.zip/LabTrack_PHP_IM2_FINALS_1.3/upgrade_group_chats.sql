-- Run this against your existing labtrack database to add group-chat support.
-- Back up the database first. Do NOT re-import database.sql into an existing database,
-- because database.sql is a fresh-install script that drops/recreates tables.
-- This migration is safe to run more than once.
USE labtrack;
CREATE TABLE IF NOT EXISTS group_chats (
  group_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  group_name VARCHAR(120) NOT NULL,
  created_by INT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_gc_creator FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS group_members (
  group_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (group_id, user_id),
  CONSTRAINT fk_gm_group FOREIGN KEY (group_id) REFERENCES group_chats(group_id) ON DELETE CASCADE,
  CONSTRAINT fk_gm_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

SET @labtrack_sql = IF(
  (SELECT COUNT(*) FROM information_schema.columns
   WHERE table_schema = DATABASE() AND table_name = 'messages' AND column_name = 'group_id') = 0,
  'ALTER TABLE messages ADD COLUMN group_id INT UNSIGNED NULL AFTER recipient_id',
  'SELECT 1'
);
PREPARE labtrack_stmt FROM @labtrack_sql;
EXECUTE labtrack_stmt;
DEALLOCATE PREPARE labtrack_stmt;

CREATE TABLE IF NOT EXISTS user_conversations (
  user_id          INT UNSIGNED NOT NULL,
  conversation_type ENUM('direct','group') NOT NULL,
  conversation_id  INT UNSIGNED NOT NULL,
  is_archived      TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted       TINYINT(1) NOT NULL DEFAULT 0,
  updated_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, conversation_type, conversation_id),
  CONSTRAINT fk_uc_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB;

SET @labtrack_sql = IF(
  (SELECT COUNT(*) FROM information_schema.table_constraints
   WHERE constraint_schema = DATABASE() AND table_name = 'messages'
     AND constraint_name = 'fk_msg_group' AND constraint_type = 'FOREIGN KEY') = 0,
  'ALTER TABLE messages ADD CONSTRAINT fk_msg_group FOREIGN KEY (group_id) REFERENCES group_chats(group_id) ON DELETE CASCADE',
  'SELECT 1'
);
PREPARE labtrack_stmt FROM @labtrack_sql;
EXECUTE labtrack_stmt;
DEALLOCATE PREPARE labtrack_stmt;
